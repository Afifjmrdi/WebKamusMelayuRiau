<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Visitor extends Model
{
    protected $fillable = ['ip_address', 'visited_at'];
    public $timestamps = false; // karena kita pakai visited_at manual
}
