<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;

class SetLocale
{
    public function handle($request, Closure $next)
    {
        $locale = session('locale', 'id'); // default Indonesia
        App::setLocale($locale);

        return $next($request);
    }
}
